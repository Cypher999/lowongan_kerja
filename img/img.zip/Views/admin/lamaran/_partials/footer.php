
		<footer class='m-5 pl-5 pr-5 bg-secondary text-light'>
			<div class='row'>
				<div class='col-lg-4'>
					<h5>About</h5>
					<p>the quick brown fox jumps over the lazy dog</p>
				</div>
				<div class='col-lg-4'>
					<h5>Contact us</h5>
					<ul class='list-unstyled text-small'>
						<li>facebook</li>
						<li>twitter</li>
						<li>instagram</li>
						<li>whatsapp</li>
						<li>PO-BOX</li>
					</ul>
				</div>
			</div>
		</footer>