<!DOCTYPE html>
<html>
	<head>
		<?php $this->view('no_login/home/__partials/head');?>
	</head>
	<body>
		<div class='container d-flex h-100 justify-content-center'>
			<div class='card col-md-8 p-5 '>
				<div class='card-header'>Silahkan jawab pertanyaan keamanan</div>
				<div class='card-body'>
					<?php if(isset($_SESSION["flash"])){
			echo $_SESSION["flash"]; unset($_SESSION["flash"]);
			 }?>
					<a href='?'><button class="btn btn-outline-danger" type='button'>Kembali</button></a>
					<form action='?a=Recover/forgot_process' method='post'>
						<?php foreach($data['forgot'] as $forgot){?>
						<label>Pertanyaan 1</label><br>
						<label><?php echo $forgot['per_1'];?></label><br>
						<label>Jawaban</label>
						<input class="form-control" type='text' name='jaw_1'>
						<label>Pertanyaan 2</label><br>
						<label><?php echo $forgot['per_2'];?></label><br>
						<label>Jawaban</label>
						<input class="form-control" type='text' name='jaw_2'>
						<?php } ?>
						<div class='row'>
							<div class='col'><input class="btn btn-outline-primary" type='submit' value='Proses'></div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $this->view('no_login/home/__partials/js');?>
	</body>
</html>