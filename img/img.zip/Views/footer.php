<div class='row bg-secondary text-light col-lg-12' style="width:100%">
				<div class='col-lg-4 p-3 m-3'>
					<h5>About</h5>
					<p>FindAJob is a website made by me, yahya, as one of my final task on this semester, please give feedback to one of my contact at the "contact us" section</p>
				</div>
				<div class='col-lg-6 p-3 m-3'>
					<h5>Contact us</h5>
					<ul class='list-unstyled text-small'>
						<li><a style="color:white" href="https://facebook.com/">facebook</a></li>
						<li><a style="color:white" href="https://wa.me/6281222105457">WhatsApp</a></li>
						<li><a style="color:white" href="https://wa.me/6281222105457">Instagram</a></li>
					</ul>
				</div>
			</div>