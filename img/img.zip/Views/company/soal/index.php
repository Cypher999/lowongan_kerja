<!DOCTYPE html>
<html>
	<?php $this->view("company/soal/__partials/head");?>
	<body>
		<?php $this->view("company/menu");?>

		<div class='container mb-5 p-2'>
			<?php if ((isset($_SESSION['flash']))&&($_SESSION['flash']!="")){
				echo $_SESSION['flash'];
				unset($_SESSION['flash']);
			}?>
			<div class="card p-2" style="border-left: solid green 3px">
				<h2>Daftar soal untuk tes</h2>
			</div>
			<div class="card p-2">
				<a href="#" class="text-success" data-toggle='modal' data-target='#modal-add'><i class="fas fa-plus"></i> Tambah Soal</a>
				<a href='<?php echo BASE_URL."?a=Loker"?>' class="text-success"><i class="fas fa-back"></i> Kembali</a>
				<table class="table table-list-lamaran table-bordered">
					<thead>
						<tr>
							<th>Nama soal</th>
							<th>Pilihan A</th>
							<th>Pilihan B</th>
							<th>Pilihan C</th>
							<th>Pilihan D</th>
							<th>Pilihan yang benar</th>
							<th>Opsi</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($data["soal"] as $soal){?>
						<tr>
							<td><?php echo $soal["soal"];?></td>
							 <td><?php echo $soal["pil_a"];?></td>
							 <td><?php echo $soal["pil_b"];?></td>
							 <td><?php echo $soal["pil_c"];?></td>
							 <td><?php echo $soal["pil_d"];?></td>
							 <td><?php echo $soal["pil_ben"];?></td>
							<td>
							<a class="text-warning" onclick="show_edit_form('<?php echo $soal['id_soal'];?>');"  href='#' data-toggle='modal' data-target='#modal-edit'  title="Edit Soal"><i class="fas fa-edit"></i></a>
							
							<a href='?a=Soal/delete&&key=<?php echo $soal['id_soal'];?>' class="text-danger" title="Hapus Soal"><i class="fas fa-trash"></i></a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="modal" id='modal-edit'>

			</div>
			<div class="modal" id='modal-add'>
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h2>Tambah Soal Tes</h2>
						</div>
						<div class="modal-body">
							<input type="button" value="[ X ]" class="btn btn-outline-danger" data-dismiss="modal">
						<form action='?a=Soal/insert&&key=<?php echo $_GET['key'];?>' method='post' enctype='multipart/form-data'>
							<label>Nama Soal</label>
							<input type="text" class="form-control" name='soal' placeholder="Nama Soal">
							<label>Pilihan pertama</label>
							<input type="text" class="form-control" name='pil_a' placeholder="pilihan pertama">
							<label>Pilihan kedua</label>
							<input type="text" class="form-control" name='pil_b' placeholder="pilihan kedua">
							<label>Pilihan ketiga</label>
							<input type="text" class="form-control" name='pil_c' placeholder="pilihan ketiga">
							<label>Pilihan keempar</label>
							<input type="text" class="form-control" name='pil_d' placeholder="pilihan keempat">
							<label>Pilihan yang benar</label>
							<select class="form-control" name='pil_ben'>
								<option value='A'>A</option>
								<option value='B'>B</option>
								<option value='C'>C</option>
								<option value='D'>D</option>
							</select><br>
							<div class="row">
								<div class="col"><input type="submit" value='simpan lamaran' class="btn btn-outline-primary"></div>
								<div class="col"><input type="reset" value='reset' class="btn btn-outline-primary"></div>
							</div>

						</form>
					</div>
				</div>
			</div>
		<?php $this->view("footer");?>
		<?php $this->view("company/soal/__partials/js");?>
	</body>
</html>
