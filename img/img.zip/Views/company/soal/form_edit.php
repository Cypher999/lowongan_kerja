<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h2>Edit lowongan Pekerjaan</h2>
						</div>
						<div class="modal-body">
							<input type="button" value="[ X ]" class="btn btn-outline-danger" data-dismiss="modal">
							<?php foreach ($data['soal'] as $soal){?>
						<form action='?a=Soal/update&&key=<?php echo $_GET['key'];?>' method='post' enctype='multipart/form-data'>
							<label>Nama Soal</label>
							<input type="text" value="<?php echo $soal['soal'];?>" class="form-control" name='soal' placeholder="Nama Soal">
							<label>Pilihan pertama</label>
							<input type="text"  value="<?php echo $soal['pil_a'];?>" class="form-control" name='pil_a' placeholder="pilihan pertama">
							<label>Pilihan kedua</label>
							<input type="text" class="form-control" value="<?php echo $soal['pil_b'];?>" name='pil_b' placeholder="pilihan kedua">
							<label>Pilihan ketiga</label>
							<input type="text" class="form-control" value="<?php echo $soal['pil_c'];?>" name='pil_c' placeholder="pilihan ketiga">
							<label>Pilihan keempar</label>
							<input type="text" class="form-control" value="<?php echo $soal['pil_d'];?>" name='pil_d' placeholder="pilihan keempat">
							<label>Pilihan yang benar</label>
							<select class="form-control" name='pil_ben'>
								<option value='A' <?php if($soal['pil_ben']=="A"){echo 'selected';}?>>A</option>
								<option value='B' <?php if($soal['pil_ben']=="B"){echo 'selected';}?>>B</option>
								<option value='C' <?php if($soal['pil_ben']=="C"){echo 'selected';}?>>C</option>
								<option value='D' <?php if($soal['pil_ben']=="D"){echo 'selected';}?>>D</option>
							</select><br>
							<div class="row">
								<div class="col"><input type="submit" value='simpan lamaran' class="btn btn-outline-primary"></div>
								<div class="col"><input type="reset" value='reset' class="btn btn-outline-primary"></div>
							</div>

						</form>
						<?php } ?>
					</div>
				</div>