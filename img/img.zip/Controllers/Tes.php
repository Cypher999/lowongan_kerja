<?php
class Tes extends Controller{
	private $Model_soal;
	private $Model_lamaran;
	private $tipe_user;
	private $Model_hasil_tes;
	private $Model_user;
	private $path;
	public function __construct(){
		$this->Model_user=$this->model("Model_user");
		$this->Model_soal=$this->model("Model_soal");
		$this->Model_lamaran=$this->model("Model_lamaran");
		$this->Model_hasil_tes=$this->model("Model_hasil_tes");
		$this->Model_user=$this->model("Model_user");
		if(empty($_SESSION["user_loker"])){
			header("Location: ".BASE_URL."?");
			exit();
		}
		else{
			$cek_tipe=$this->Model_user->read_one($_SESSION["user_loker"]);
			if($cek_tipe[0]["tipe_user"]=="P"){
				$this->path="applyer";
			}
			else if($cek_tipe[0]["tipe_user"]=="C"){
				$this->path="company";
			}
			else if($cek_tipe[0]["tipe_user"]=="A"){
				$this->path="admin";
			}
			else{
				$this->path="no_login";	
			}
		}
	}
	public function index(){
		$this->view("applyer/tes/index");	
	}
	public function review(){
		$a['id_loker']=htmlspecialchars($_GET['key']);
		if($this->path=="applyer"){
			$a['id_user']=$_SESSION['user_loker'];
		}
		else{
			$a['id_user']=$_GET['applyer'];	
		}
		$data['jwb']=$this->Model_hasil_tes->read_jwb_tes($a);
		$this->view($this->path."/tes/review",$data);
	}
	public function result(){
		$a["id_loker"]=htmlspecialchars($_GET['key']);
		$a['form-tes']["id_user"]=$_SESSION["user_loker"];
		$a['form-tes']["tgl_tes"]=date("Y/m/d h:i:s");
		$a['stat_lam']="X";
		$isi_soal=$this->Model_soal->read_soal($a["id_loker"]);
		foreach ($isi_soal as $is_soal) {
			$a['form-tes']['id_jwb']=random(6);
			$a['form-tes']['id_soal']=$is_soal['id_soal'];
			$a['form-tes']['jawaban']=$_POST[$is_soal['id_soal']];
			$insert_result=$this->Model_hasil_tes->insert($a['form-tes']);
		}
		$update_status=$this->Model_lamaran->update_status_lamaran(["stat_lam"=>'X',
			"id_user"=>$a['form-tes']["id_user"],
			"id_loker"=>$a["id_loker"],
			]);
	}
	public function start(){
		$a['id_loker']=htmlspecialchars($_GET["key"]);
		$a['id_user']=$_SESSION['user_loker'];
		$cek_tes=$this->Model_hasil_tes->cek_sudah_tes($a);
		if($cek_tes>0){
			header("Location: ".BASE_URL."?a=Tes/review&&key=".$a['id_loker']);
			exit();
		}
		$data["soal"]=$this->Model_soal->read_soal($a["id_loker"]);
		$this->view("applyer/tes/start",$data);	
	}
	public function read_one_soal(){
		$a=htmlspecialchars($_GET["key"]);
		$data["soal"]=$this->Model_soal->read_one($a);
		$this->view("applyer/tes/read_one_soal",$data);	
	}
}
?>

