<?php
class Soal extends Controller{
	private $Model_company;
	private $Model_lamaran;
	private $Model_low_ker;
	private $Model_user;
	private $Model_bidang;
	private $path;
	public function __construct(){
		$this->Model_company=$this->model("Model_company");
		$this->Model_lamaran=$this->model("Model_lamaran");
		$this->Model_low_ker=$this->model("Model_low_ker");
		$this->Model_bidang=$this->model("Model_bidang");
		$this->Model_soal=$this->model("Model_soal");
		$this->Model_user=$this->model("Model_user");
		if(isset($_SESSION["user_loker"])){
			$cek_tipe=$this->Model_user->read_one($_SESSION["user_loker"]);
			if($cek_tipe[0]["tipe_user"]=="P"){
				$this->path="applyer";
			}
			else if($cek_tipe[0]["tipe_user"]=="C"){
				$this->path="company";
			}
			else if($cek_tipe[0]["tipe_user"]=="A"){
				$this->path="admin";
			}
			else{
				$this->path="no_login";	
			}
		}
	}
	public function index(){
		$id_loker=htmlspecialchars($_GET['key']);
		$data['soal']=$this->Model_soal->read_soal($id_loker);
		$this->view($this->path."/soal/index",$data);
	}
	public function form_edit(){
		$id_soal=htmlspecialchars($_GET['key']);
		$data['soal']=$this->Model_soal->read_one($id_soal);
		$this->view($this->path."/soal/form_edit",$data);
	}
	public function delete(){
		$id_soal=htmlspecialchars($_GET['key']);
		$key_return=$this->Model_soal->read_one($id_soal);
		$delete=$this->Model_soal->delete($id_soal);
		if($delete){
			$_SESSION['flash']="<h2>Soal sudah dihapus</h2>";
			header("Location: ".BASE_URL."?a=Soal&&key=".$key_return[0]['id_loker']);
		}
		else{
			echo $this->Model_soal->db->show_error();
		}
	}
	public function update(){
		$a["id_soal"]=htmlspecialchars($_GET['key']);
		$a['form-data']['soal']=htmlspecialchars($_POST['soal']);
		$a['form-data']['pil_a']=htmlspecialchars($_POST['pil_a']);
		$a['form-data']['pil_b']=htmlspecialchars($_POST['pil_b']);
		$a['form-data']['pil_c']=htmlspecialchars($_POST['pil_c']);
		$a['form-data']['pil_d']=htmlspecialchars($_POST['pil_d']);
		$a['form-data']['pil_ben']=htmlspecialchars($_POST['pil_ben']);
		$update=$this->Model_soal->update($a);
		if($update){
			$_SESSION['flash']="<h2>Soal telah diupdate</h2>";
			$key_return=$this->Model_soal->read_one($a["id_soal"]);
			header("Location: ".BASE_URL."?a=Soal&&key=".$key_return[0]['id_loker']);
		}
		else{
			echo $this->Model_soal->db->show_error();
		}
	}
	public function insert(){
		$a["id_soal"]=random(8);
		$a["id_loker"]=htmlspecialchars($_GET['key']);
		$a['soal']=htmlspecialchars($_POST['soal']);
		$a['pil_a']=htmlspecialchars($_POST['pil_a']);
		$a['pil_b']=htmlspecialchars($_POST['pil_b']);
		$a['pil_c']=htmlspecialchars($_POST['pil_c']);
		$a['pil_d']=htmlspecialchars($_POST['pil_d']);
		$a['pil_ben']=htmlspecialchars($_POST['pil_ben']);
		$insert=$this->Model_soal->insert($a);
		if($insert){
			$_SESSION['flash']="<h2>Soal baru telah ditambahkan</h2>";
			header("Location: ".BASE_URL."?a=Soal&&key=".$_GET['key']);
		}
		else{
			echo $this->Model_soal->db->show_error();
		}
	}
}
?>

