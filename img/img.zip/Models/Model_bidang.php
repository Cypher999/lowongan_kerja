<?php
class Model_bidang{
	private $table;
	public $db;
	function __construct(){
		$this->db=new lawliet_query_builder();
		$this->table='bidang';
	}

	function read_all(){
		return $this->db->table_name($this->table)->select("*")->result();
	}
}
?>
