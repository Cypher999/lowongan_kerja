<?php
class Model_soal{
	private $table;
	public $db;
	public function __construct(){
		$this->db=new lawliet_query_builder();
		$this->table='soal';
	}
	public function read_soal($a){
		return $this->db->table_name($this->table)->select("*")->where("id_loker='".$a."'")->result();
	}

	public function read_username($a){
		return $this->db->table_name($this->table)->select("*")->where("nm_user='".$a."' or email='".$a."'")->result();
	}
	public function read_one($a){
		return $this->db->table_name($this->table)->select("*")->where("id_soal='".$a."'")->result();
	}
	public function delete($a){
		return $this->db->table_name($this->table)->where("id_soal='".$a."'")->delete();
	}
	public function delete_loker($a){
		return $this->db->table_name($this->table)->where("id_loker='".$a."'")->delete();
	}
	public function insert($a){
		return $this->db->table_name($this->table)->set_var($a)->create();	
	}
	public function update($a){
		return $this->db->table_name($this->table)->set_var($a['form-data'])->where("id_soal='".$a['id_soal']."'")->update();	
	}
}
?>