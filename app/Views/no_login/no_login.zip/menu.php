<nav class="navbar navbar-expand-md bg-success navbar-dark" style="z-index: 1000;width: 100%">
	<a class="navbar-brand" href="<?php echo BASE_URL;?>">Find a Job</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsiblenavbar">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="collapsiblenavbar">
		<ul class="navbar-nav">
			<li class="nav-item">
				<div class='nav-link'>
					<a class="btn sing-it" href="?a=Home/login">Login</a>
				</div>
			</li>
			<li class="nav-item">
				<div class='nav-link'>
					<a class="btn sing-it" href="?a=Home/signup">Sign up</a>
				</div>
			</li>			
			<li class="nav-item">
				<div class='nav-link'>
					<a class="btn sing-it" href="?a=Company_list">Lihat Perusahaan</a>
				</div>
			</li>
		</ul>
	</div>
</nav>